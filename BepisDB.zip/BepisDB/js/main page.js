let slide_track = $(".slide-track");

slide_track.hover(function() {
    slide_track.css("animation-play-state", "paused");
    slide_track.css("-webkit-animation-play-state", "paused");
},
function () {
    slide_track.css("animation-play-state", "running");
    slide_track.css("-webkit-animation-play-state", "running");
});