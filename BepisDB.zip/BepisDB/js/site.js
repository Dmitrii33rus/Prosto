﻿function countDownload(cardType, cardId)
{
    $.ajax({
        type: "POST",
        url: "/card/count",
        data: {
            cardType: cardType,
            cardId: cardId
        },
        async: false
    });

    return true;
}