function addsongs () {
    let song1 = document.getElementById ("song1");
    let song2 = document.getElementById ("song2");
    let song3 = document.getElementById ("song3");
    let song4 = document.getElementById ("song4");
    let song5 = document.getElementById ("song5");
    let song6 = document.getElementById ("song6");

    song1.innerHTML = "https://www.youtube.com/watch?v=GCdwKhTtNNw&list=PLmzgxEPGSJRQyQNE3FdJ02mOBI_tWNtYH&index=4"
    song2.innerHTML = "https://www.youtube.com/watch?v=ovGHntUvbmQ"
    song3.innerHTML = "https://www.youtube.com/watch?v=SKnRdQiH3-k"
    song4.innerHTML = "https://www.youtube.com/watch?v=HfySji7kNi0"
    song5.innerHTML = "https://www.youtube.com/watch?v=fqR2HGkjFCA"
    song6.innerHTML = "https://www.youtube.com/watch?v=Fve_lHIPa-I"
}
window.onload = addsongs